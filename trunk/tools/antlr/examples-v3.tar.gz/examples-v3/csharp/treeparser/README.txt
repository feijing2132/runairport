Hi there,

This is a simple demo of tree construction and tree parsing with ANTLR
v3.  Here's how to try it out.

$ nant
$ bin\tparse input

You should see the following output on the console:

tree: (DECL int a)
int a
