class Test def method1 a = 2 return a end def method2 a = 3 b = method1 
return a end end
