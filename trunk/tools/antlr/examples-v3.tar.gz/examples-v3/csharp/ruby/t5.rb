class A def method1 return 1 end end class B < A def method1 return 2 end 
def method2 return 3 end end

