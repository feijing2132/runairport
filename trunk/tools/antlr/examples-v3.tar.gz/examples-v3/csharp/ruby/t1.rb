class A 
def method 
  return 1 
end 
end
