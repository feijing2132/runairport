class Test def method1(n) n = 3 return n end def method2 n = 2 m = 
method1(n) return n + m end end
