a = []
b = 3 # test end of line

# two in a row
# bar

# all by itself

# before stmt
a = 3

a = 4
# after

