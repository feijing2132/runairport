class OutputBuffer:
	def __init__(self, console, stylename):
		a=1;b=4;

		b=3;
		
	def flush(self):
		pass
		
	a = [1,2,
	     3,4, # comment

		# blank lines + comments ok

	     5]
