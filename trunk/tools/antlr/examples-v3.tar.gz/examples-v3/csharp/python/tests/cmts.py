"""This is a substantially improved version of the older Interpreter.py demo
It creates a simple GUI JPython console window with simple history
as well as the ability to interupt running code (with the ESC key).

Like Interpreter.py, this is still just a demo, and needs substantial
work before serious use.
"""
class C:
    if a<1:
        a=1
        return a

    # Essentially static class variables

    # ignore the newline above me
    # blort
    # foo
    protocol_version = "HTTP/1.0"

