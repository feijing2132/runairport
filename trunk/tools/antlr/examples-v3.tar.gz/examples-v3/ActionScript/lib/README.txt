Copy the following files to this directory:

antlr3.swc - The ActionSript ANTLR runtime

antlr-3.1.jar - The ANTLR 3.1 Java Runtime
antlr-2.7.7.jar - The ANTLR 2.7.x Java Runtime
string-template-3.1.jar - The String Template 3.1 Java Runtime

