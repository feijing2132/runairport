typedef unsigned int JIM;

