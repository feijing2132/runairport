#ifndef	_ISLANDFUNCS_H
#define	_ISLANDFUNCS_H

// External function that sets up and calls a Simple parser
//
extern	void	callSimple(pANTLR3_INPUT_STREAM input);

// External function that sets up and calls a JavaDoc parser
//
extern	void	callJavadoc(pANTLR3_INPUT_STREAM input);

#endif
